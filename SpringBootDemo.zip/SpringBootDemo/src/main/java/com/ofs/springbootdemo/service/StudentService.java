package com.ofs.springbootdemo.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ofs.springbootdemo.entity.StudentEntity;

@Service
public class StudentService {

	public List<StudentEntity> students = new ArrayList<>(Arrays.asList(
			new StudentEntity(1438,"Kannan"),
			new StudentEntity(1437,"Bala"),
			new StudentEntity(1439,"Ravi")
			));
	
	public List<StudentEntity> getAll(){
		return students;
	}
	
	public StudentEntity getStudent(int id) {
		return students.stream().filter(student -> student.getId() == id).findFirst().get();
	}

	public void addStudent(StudentEntity student) {
		students.add(student);
	}

	public void updateStudent(StudentEntity student, int id) {
		for(int i=0;i<students.size();i++) {
			StudentEntity s = students.get(i);
			if(s.getId()==id) {
				students.set(i, student);
				return;
			}
		}
		
	}

	public void deleteStudent(int id) {
		students.removeIf(student -> student.getId() == id);
	}
}
