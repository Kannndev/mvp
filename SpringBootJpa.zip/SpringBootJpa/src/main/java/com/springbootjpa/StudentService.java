package com.springbootjpa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
	
	public List<StudentEntity> students = new ArrayList<>(Arrays.asList(
			new StudentEntity(1438,"Kannan"),
			new StudentEntity(1437,"Bala"),
			new StudentEntity(1439,"Ravi")
			));
	
	public List<StudentEntity> getAll(){
		List<StudentEntity> students = new ArrayList<>();
		studentRepository.findAll().forEach(students::add);
		return students;
	}
	
	public StudentEntity getStudent(int id) {
		//return students.stream().filter(student -> student.getId() == id).findFirst().get();
		return studentRepository.findOne(id);
	}

	public void addStudent(StudentEntity student) {
		studentRepository.save(student);
	}

	public void updateStudent(StudentEntity student, int id) {
		studentRepository.save(student);
	}

	public void deleteStudent(int id) {
		studentRepository.delete(id);
	}
}
