package com.springbootjpa.employee;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	public EmployeeService employeeService;
	
	@RequestMapping("/hello")
	public String Hello() {
		return "Hello";
	}
	
	@RequestMapping("/students")
	public List<EmployeeEntity> getList(){
		return employeeService.getAll();
	}
	
	@RequestMapping("/students/{id}")
	public EmployeeEntity getEmployee(@PathVariable int id) {
		return employeeService.getEmployee(id);
	}
	
	@RequestMapping(method = RequestMethod.POST, value="/students")
	public void addEmployee(@RequestBody EmployeeEntity employee) {
		employeeService.addEmployee(employee);
	}
	
	@RequestMapping(method = RequestMethod.PUT, value="/students/{id}")
	public void updateEmployee(@RequestBody EmployeeEntity employee, @PathVariable int id) {
		employeeService.updateEmployee(employee,id);
	}
	
	@RequestMapping(method = RequestMethod.DELETE, value="/students/{id}")
	public void deleteEmployee(@PathVariable int id) {
		employeeService.deleteEmployee(id);
	}
}
