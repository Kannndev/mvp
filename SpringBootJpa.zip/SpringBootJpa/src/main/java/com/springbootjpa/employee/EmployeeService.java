package com.springbootjpa.employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	public List<EmployeeEntity> students = new ArrayList<>(Arrays.asList(
			new EmployeeEntity(1438,"Kannan"),
			new EmployeeEntity(1437,"Bala"),
			new EmployeeEntity(1439,"Ravi")
			));
	
	public List<EmployeeEntity> getAll(){
		List<EmployeeEntity> employees = new ArrayList<>();
		employeeRepository.findAll().forEach(employees::add);
		return employees;
	}
	
	public EmployeeEntity getEmployee(int id) {
		//return students.stream().filter(student -> student.getId() == id).findFirst().get();
		return employeeRepository.findOne(id);
	}

	public void addEmployee(EmployeeEntity employee) {
		employeeRepository.save(employee);
	}

	public void updateEmployee(EmployeeEntity employee, int id) {
		employeeRepository.save(employee);
	}

	public void deleteEmployee(int id) {
		employeeRepository.delete(id);
	}
}
