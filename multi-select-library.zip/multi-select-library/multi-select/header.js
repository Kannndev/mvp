import React from "react";

const DropdownHeader = ({ value, options, valueRenderer, overrideStrings }) => {
  const noneSelected = value.length === 0;
  const allSelected = value.length === options.length;
  const customText = valueRenderer && valueRenderer(value, options);

  const getSelectedText = () => value.map((s) => s.label).join(", ");

  return noneSelected ? (
    <span className="gray">
      {customText || ''}
    </span>
  ) : (
    <span>
      {customText ||
        (allSelected
          ? 'All Selected'
          : getSelectedText())}
    </span>
  );
};

export default DropdownHeader;
