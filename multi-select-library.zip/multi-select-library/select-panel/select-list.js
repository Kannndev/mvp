/**
 * This component represents an unadorned list of SelectItem (s).
 */
import { css } from "goober";
import React from "react";

import SelectItem from "./select-item";

const SelectListUl = css({
  margin: 0,
  paddingLeft: 0,
  li: {
    listStyle: "none",
    margin: 0,
  },
});

const skipIndex = 2;

const SelectList = ({
  value,
  onChange,
  disabled,
  ItemRenderer,
  options,
  focusIndex,
  onClick,
}) => {
  const handleSelectionChanged = (option, checked) => {
    if (disabled) {
      return;
    }
    onChange(
      checked
        ? [...value, option]
        : value.filter((o) => o.value !== option.value)
    );
  };

  return (
    <ul className={SelectListUl}>
      {options.map((o, i) => {
        const tabIndex = i + skipIndex;
        return (
          <li key={o.hasOwnProperty("key") ? o.key : i}>
            <SelectItem
              focused={focusIndex === tabIndex}
              tabIndex={tabIndex}
              option={o}
              onSelectionChanged={(c) => handleSelectionChanged(o, c)}
              checked={value.find((s) => s.value === o.value) ? true : false}
              onClick={(e) => onClick(e, tabIndex)}
              itemRenderer={ItemRenderer}
              disabled={o.disabled || disabled}
            />
          </li>
        );
      })}
    </ul>
  );
};

export default SelectList;
