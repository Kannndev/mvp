import { css } from "goober";
import React from "react";


const DefaultRenderer = css({
  "& input,& span": {
    verticalAlign: "middle",
    margin: 0,
  },
  span: {
    display: "inline-block",
    paddingLeft: "5px",
  },
  "&.disabled": {
    opacity: 0.5,
  },
});

const DefaultItemRenderer = ({
  checked,
  option,
  onClick,
  disabled,
}) => {
  return (
    <div
      className={`${DefaultRenderer} item-renderer ${disabled && "disabled"}`}
    >
      <input
        type="checkbox"
        onChange={onClick}
        checked={checked}
        tabIndex={-1}
        disabled={disabled}
      />
      <span>{option.label}</span>
    </div>
  );
};

export default DefaultItemRenderer;
